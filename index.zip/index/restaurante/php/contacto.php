
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = htmlspecialchars($_POST["nombre"]);
    $email = htmlspecialchars($_POST["email"]);
    $mensaje = htmlspecialchars($_POST["mensaje"]);

    echo "Gracias, $nombre. Tu mensaje ha sido recibido.";
    // Puedes modificar esto para guardarlo en la base de datos o enviarlo por correo

   // $to = "tu_correo@ejemplo.com";
    //$subject = "Nuevo mensaje de contacto";
    //$body = "Nombre: $nombre\nCorreo: $email\nMensaje:\n$mensaje";

    //if (mail($to, $subject, $body)) {
      //  echo "Mensaje enviado correctamente.";
    //} else {
      //  echo "Hubo un error al enviar el mensaje.";
    //}
}
?>
