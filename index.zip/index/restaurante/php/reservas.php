<?php
// Datos de conexión
$host = "localhost";
$usuario = "root";
$clave = "abc123.";
$bd = "restaurante";

// Crear conexión
$conexion = new mysqli($host, $usuario, $clave, $bd);

// Comprobar conexión
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// Conexión á base de datos (asumo que $conexion xa está definida)

// 1. Obtener e sanitizar os datos do formulario
$nombre = $conexion->real_escape_string($_POST['nombre']);
$telefono = $conexion->real_escape_string($_POST['telefono']);
$email = $conexion->real_escape_string($_POST['email']);
$fecha = $conexion->real_escape_string($_POST['fecha']);
$hora = $conexion->real_escape_string($_POST['hora']);
$personas = intval($_POST['personas']);
$mensaje = $conexion->real_escape_string($_POST['mensaje']);

// 2. Comprobar se o cliente xa existe
$sql_cliente = "SELECT id FROM clientes WHERE nombre = '$nombre' AND telefono = '$telefono'";
$result = $conexion->query($sql_cliente);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $id_cliente = $row['id'];
} else {
    // Se non existe, insertalo
    $sql_insert_cliente = "INSERT INTO clientes (nombre, telefono, fecha_registro) VALUES ('$nombre', '$telefono', NOW())";
    if ($conexion->query($sql_insert_cliente) === TRUE) {
        $id_cliente = $conexion->insert_id;
    } else {
        echo "Erro ao inserir o cliente: " . $conexion->error;
        exit;
    }
}

// 3. Escoller unha mesa dispoñible (exemplo: mesa 1)
$id_mesa = 1; // Isto deberías adaptalo se queres asignación real dinámica

// 4. Estado por defecto: 'Pendiente', supoñendo que é id = 1
$id_estado = 1;

// 5. Inserir a reserva
$sql_reserva = "INSERT INTO reservas (id_cliente, id_mesa, id_estado, fecha, hora, personas, mensaje)
                VALUES ($id_cliente, $id_mesa, $id_estado, '$fecha', '$hora', $personas, '$mensaje')";

if ($conexion->query($sql_reserva) === TRUE) {
    echo "Reserva realizada correctamente.";
    $para = "info@bar.local";
    $asunto = "Nova reserva dende a web";
    $correo = "Nova reserva:\n\n";
    $correo .= "Nome: $nombre\n";
    $correo .= "Teléfono: $telefono\n";
    $correo .= "Email: $email\n";
    $correo .= "Data: $fecha\n";
    $correo .= "Hora: $hora\n";
    $correo .= "Número de persoas: $personas\n";
    $correo .= "Comentario: $mensaje\n";

    $cabeceras = "From: noreply@restaurante.local";
    // Enviar correo
    mail($para, $asunto, $correo, $cabeceras);
} else {
    echo "Erro ao inserir a reserva: " . $conexion->error;
}
