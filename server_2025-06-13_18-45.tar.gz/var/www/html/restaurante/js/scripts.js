window.addEventListener('DOMContentLoaded', () => {
    console.log("Página cargada correctamente.");
  });


  function toggleCategoria(id) {
    const section = document.getElementById(id);
    section.classList.toggle("oculto");
  }
  