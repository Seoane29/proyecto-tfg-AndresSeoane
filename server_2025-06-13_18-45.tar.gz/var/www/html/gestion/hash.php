<?php
echo password_hash("1234secure", PASSWORD_DEFAULT);
?>
