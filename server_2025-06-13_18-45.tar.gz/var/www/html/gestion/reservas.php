<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$conexion = new mysqli('localhost', 'root', 'abc123.', 'restaurante');
if ($conexion->connect_error) {
    die("Error conexión: " . $conexion->connect_error);
}

$sql = "SELECT r.*, c.nombre, c.telefono
        FROM reservas r
        JOIN clientes c ON r.id_cliente = c.id
        ORDER BY r.fecha, r.hora";

$resultado = $conexion->query($sql);

if (!$resultado) {
    die("Error en la consulta SQL: " . $conexion->error);
}

echo "<p>Filas encontradas: " . $resultado->num_rows . "</p>";
?>

<!DOCTYPE html>
<html>
<head><title>Reservas</title></head>
<body>
<h2>Panel de reservas</h2>
<p>Usuario: <?= htmlspecialchars($_SESSION['usuario']) ?> | <a href="logout.php">Cerrar sesión</a></p>

<table border="1" cellpadding="5" cellspacing="0">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Teléfono</th>
            <th>Fecha</th>
            <th>Hora</th>
            <th>Personas</th>
            <th>Mensaje</th>
        </tr>
    </thead>
    <tbody>
    <?php
    if ($resultado->num_rows > 0) {
        while ($fila = $resultado->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($fila['nombre']) . "</td>";
            echo "<td>" . htmlspecialchars($fila['telefono']) . "</td>";
            echo "<td>" . htmlspecialchars($fila['fecha']) . "</td>";
            echo "<td>" . htmlspecialchars($fila['hora']) . "</td>";
            echo "<td>" . htmlspecialchars($fila['personas']) . "</td>";
            echo "<td>" . htmlspecialchars($fila['mensaje']) . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'>No hay reservas</td></tr>";
    }
    ?>
    </tbody>
</table>
</body>
</html>

<?php
$conexion->close();
?>
